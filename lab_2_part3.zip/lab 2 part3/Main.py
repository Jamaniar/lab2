from invoice import Invoice
products = {}
total_amount = 0
repeat = " "
while True:
    product = input("what is your product: ")
    unit_price = Invoice().inputNumber("please enter unit price: ")
    qnt = Invoice().inputNumber("please enter quantiy of the the product: ")
    discount = Invoice().inputNumber("discount percent(%): ")
    repeat = Invoice().inputAnswer("another product? (y,n): ")
    result = Invoice().addProduct(qnt,unit_price,discount)
    products[product] = result
    if repeat == "n":
        break
total_amount = Invoice().totalPurePrice(products)

print("your total pure price is: " + str(total_amount))